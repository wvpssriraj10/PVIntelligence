# PV Data Engineering & Preprocessing Pipeline

## Role
Data Engineering & Preprocessing Lead for Solar PV forecasting.

## Dataset
Two plants are included:
- Plant 1 Generation + Weather
- Plant 2 Generation + Weather

## Pipeline
Raw CSV -> Load -> EDA -> Clean -> Aggregate inverter records -> Merge weather -> Feature engineering -> Time split -> Scale -> Processed data

## Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run preprocessing
From the project root:
```bash
python src/preprocessing.py
```

This creates:
```text
data/processed/plant_1/
data/processed/plant_2/
```

Each plant contains:
- cleaned_full.csv
- train.csv
- validation.csv
- test.csv

### 3. Run EDA
Open:
```text
notebooks/01_eda.ipynb
```

and run all cells.

## Important ML rule
Do not randomly shuffle this dataset when creating train/validation/test data. This is a time-series forecasting problem, so chronological splitting is used.

## Suggested forecasting target
`AC_POWER`

## Suggested model features
- IRRADIATION
- AMBIENT_TEMPERATURE
- MODULE_TEMPERATURE
- DC_POWER
- hour_sin
- hour_cos
- day_sin
- day_cos

The LSTM/GRU/transfer-learning model can consume the processed train/validation/test data produced here.

### Important preprocessing safeguards
- Plant 1 timestamps are parsed with `dayfirst=True` because the source data uses `DD-MM-YYYY HH:MM`.
- Missing-value interpolation preserves group/index alignment.
- Chronological train/validation/test splitting is used; random shuffling should not be used for forecasting.
- Feature scalers must be fitted on the training period only and then applied to validation/test data.
